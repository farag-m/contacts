window.onload = desplayContacts;


// Variables

    let     contactsList            = [], // Contacts list
            newButton               = document.querySelector('#new-button'),
            newContactForm          = document.querySelector('#new-contact-form'),
            closeNewContactForm     = document.querySelector('#new-contact-form .close-button'),
            contactFormID           = contactsList.length,
            contactFormPhoto        = document.querySelector('#contact-form-photo'),
            contactFormName         = document.querySelector('#contact-form-name'),
            contactFormPhone        = document.querySelector('#contact-form-phone'),
            contactFormEmail        = document.querySelector('#contact-form-email'),
            contactFormAddress      = document.querySelector('#contact-form-address'),
            saveButton              = document.querySelector('#new-contact-form #save-button')
            tableBody               = document.querySelector('#contacts tbody'),
            contactRows             = document.querySelectorAll('tbody'),
            contactInfo             = document.querySelector('#contact-info'),
            closeContactInfo        = document.querySelector('#contact-info .close-button');


    


// Functions

    // Reset contact form
    function resetContactForm(){
        return  contactFormPhoto.value      = '',
                contactFormName.value       = '',
                contactFormPhone.value      = '',
                contactFormEmail.value      = '',
                contactFormAddress.value    = '';
    }

    // Toggle show
    function toggleShow(x){
        return x.classList.toggle('show');
    }

    // Add new contact
    function newContact(){
        contactsList.push(
            {
                contactID       : contactFormID += 1,
                contactPhoto    : contactFormPhoto.value,
                contactName     : contactFormName.value,
                contactPhone    : contactFormPhone.value,
                contactEmail    : contactFormEmail.value,
                contactAddress  : contactFormAddress.value
            },
        );
        localStorage.setItem('contact', contactsList);
    }

    let contact = localStorage.getItem;
    console.log(contact[0])

    // Desplay contacts
    function desplayContacts(){
        let tr ='';
        for(let i = 0 ; i < contactsList.length ; i++){
            tr += `
            <tr>
                <td class="photos">
                    <img src="${contactsList[i].contactPhoto}" alt="" />
                </td>
                <td class="names">${contactsList[i].contactName}</td>
                <td class="phones">${contactsList[i].contactPhone}</td>
                <td class="emails">${contactsList[i].contactEmail}</td>
                <td class="addresses">${contactsList[i].contactAddress}</td>
            </tr>`;
        }
        tableBody.innerHTML = tr;
    }


    // let     contactID       = contactFormID += 1 ,
    //             contactPhoto    = contactFormPhoto.value,
    //             contactName     = contactFormName.value,
    //             contactPhone    = contactFormPhone.value,
    //             contactEmail    = contactFormEmail.value,
    //             contactAddress  = contactFormAddress.value;


    // tableBody.innerHTML += `
    // <td class="photos">
    //     <img src="${contactPhoto}" alt="" />
    // </td>
    // <td class="names">${contactName}</td>
    // <td class="phones">${contactPhone}</td>
    // <td class="emails">${contactEmail}</td>
    // <td class="addresses">${contactAddress}</td>`;

    // Sort contacts names a to z
    function sortContactsNamesATZ(){
        return contactsList.sort((a,b)=> (a.contactName > b.contactName ? 1 : -1));
    }

    // Sort contacts names Z to a
    function sortContactsNamesZTA(){
        return contactsList.sort((a,b)=> (a.contactName > b.contactName ? -1 : 1));
    }


    // Desplay contact row
   



// Events

    // Open new contact form
    newButton.onclick = function(){
        toggleShow(newContactForm);
        resetContactForm();
        contactFormName.focus();
    }

    // Close new contact form
    closeNewContactForm.onclick = function(){
        toggleShow(newContactForm);
    }

    // Open contact info
    contactRows.forEach(row => {
        row.addEventListener("click", function(){
            toggleShow(contactInfo);
        })
    });

    // Close contact info
    closeContactInfo.onclick = function(){
        toggleShow(contactInfo);
    }

    // Save new contact
    saveButton.addEventListener('click', () =>{
        
        // If name field is empty
        if (contactFormName.value === ""){

            contactFormName.setAttribute("placeholder", "Requred field");
            contactFormName.classList.add('shake');

        }
        else{

            // Add new contact to contact list
            newContact();

            // Desplay
            desplayContacts();

            // Reset
            resetContactForm();

            // Close new contact form
            newContactForm.classList.toggle('show');
        }

    });

    let nameHeader = document.querySelector('thead .names');

    nameHeader.addEventListener('click', function (){
        sortContactsNamesATZ();
        desplayContacts();
    });



